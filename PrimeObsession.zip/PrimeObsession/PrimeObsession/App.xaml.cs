﻿namespace PrimeObsession
{
    public partial class App
    {
    }
}
